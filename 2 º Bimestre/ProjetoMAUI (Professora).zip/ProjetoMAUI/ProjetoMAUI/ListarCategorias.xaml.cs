namespace ProjetoMAUI;

public partial class ListarCategorias : ContentPage
{
	public ListarCategorias()
	{
		InitializeComponent();
	}
}