namespace ProjetoMAUI;

public partial class NovaCategoria : ContentPage
{
	public NovaCategoria()
	{
		InitializeComponent();
	}

    private void Button_Clicked(object sender, EventArgs e)
    {

    }
}