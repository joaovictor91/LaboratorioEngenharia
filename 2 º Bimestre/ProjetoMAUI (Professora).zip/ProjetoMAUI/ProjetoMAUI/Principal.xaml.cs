namespace ProjetoMAUI;

public partial class Principal : Shell
{
	public Principal()
	{
		InitializeComponent();
	}
}